package src.animal;

import src.Field;
import src.Location;

public abstract class Prey extends Animal {
	
	public Prey	(Field field, Location location, boolean isMale, boolean isSick)
    {
		super(field, location, isMale, isSick);
    }

}
