package src.animal;

import src.Field;
import src.Location;

public abstract class Predator extends Animal {
	
	public Predator	(Field field, Location location, boolean isMale, boolean isSick)
    {
		super(field, location, isMale, isSick);
    }

}

