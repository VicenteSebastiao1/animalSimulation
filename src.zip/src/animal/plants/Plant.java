package src.animal.plants;

import src.Field;
import src.Location;
import src.animal.FieldObject;

public class Plant extends FieldObject{
	
	public Plant(Field field, Location location)
    {
    	super(field, location);
    }
    
    

}
