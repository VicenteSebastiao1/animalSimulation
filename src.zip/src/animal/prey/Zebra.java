package src.animal.prey;

import static src.animal.Animal.rand;

import java.util.List;
import java.util.Random;

import src.Field;
import src.Location;
import src.Randomizer;
import src.animal.Animal;
import src.animal.Prey;

public class Zebra extends Prey{
	// The age at which a Zebra can start to breed.
    private static final int BREEDING_AGE = 1;
    // The age to which a Zebra can live.
    private static final int MAX_AGE = 50;
    // The likelihood of a Zebra breeding.
    private static final double BREEDING_PROBABILITY = 0.08;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 1;
    // The food value of a single prey. In effect, this is the
    // number of steps a Zebra can go before it has to eat again.
    private static final int PLANT_FOOD_VALUE = 5;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
	

    public Zebra(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
            foodLevel = rand.nextInt(ZEBRA_FOOD_VALUE);
            this.isSick = rand.nextDouble() < 0.1;
        }
        else {
            age = 0;
            foodLevel = ZEBRA_FOOD_VALUE;
            this.isSick = false;
        }
    }

	@Override
	public void act(List<Animal> newZebras) {
		incrementAge(MAX_AGE);
        incrementHunger();
        if(isAlive()) {
            giveBirth(newZebras);            
            // Move towards a source of food if found.
            Location newLocation = findFood();
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
		
	}

}
