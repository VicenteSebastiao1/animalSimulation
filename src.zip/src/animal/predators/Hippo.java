package src.animal.predators;

import java.util.List;
import java.util.Random;

import src.Field;
import src.Location;
import src.Randomizer;
import src.animal.Animal;
import src.animal.Predator;

public class Hippo extends Predator {
	// The age at which a Hippo can start to breed.
    private static final int BREEDING_AGE = 8;
    // The age to which a Hippo can live.
    private static final int MAX_AGE = 250;
    // The likelihood of a Hippo breeding.
    private static final double BREEDING_PROBABILITY = 0.05;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 1;
    // The food value of a single prey. In effect, this is the
    // number of steps a Zebra can go before it has to eat again.
    private static final int ANTELOPE_FOOD_VALUE = 15;
    private static final int GIRAFFE_FOOD_VALUE = 25;
    private static final int ZEBRA_FOOD_VALUE = 20;
    private static final int PLANT_FOOD_VALUE = 5;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();

    public Hippo(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
            foodLevel = rand.nextInt(HIPPO_FOOD_VALUE);
            this.isSick = rand.nextDouble() < 0.1;
        }
        else {
            age = 0;
            foodLevel = HIPPO_FOOD_VALUE;
            this.isSick = false;
        }
    }

	@Override
	public void act(List<Animal> newHippos) {
		incrementAge(MAX_AGE);
        incrementHunger();
        if(isAlive()) {
            giveBirth(newHippos);            
            // Move towards a source of food if found.
            Location newLocation = findFood();
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
		
	}

}
