package src.animal.predators;

import static src.animal.Animal.rand;

import java.util.List;
import java.util.Random;

import src.Field;
import src.Location;
import src.Randomizer;
import src.animal.Animal;
import src.animal.Predator;

public class Crocodile extends Predator {
	// The age at which a Crocodile can start to breed.
    private static final int BREEDING_AGE = 30;
    // The age to which a Crocodile can live.
    private static final int MAX_AGE = 500;
    // The likelihood of a Crocodile breeding.
    private static final double BREEDING_PROBABILITY = 0.25;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 50;
    // The food value of a single rabbit. In effect, this is the
    // number of steps a Crocodile can go before it has to eat again.
    private static final int ANTELOPE_FOOD_VALUE = 2;
    private static final int GIRAFFE_FOOD_VALUE = 10;
    private static final int ZEBRA_FOOD_VALUE = 4;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();

    public Crocodile(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
            foodLevel = rand.nextInt(CROCODILE_FOOD_VALUE);
            this.isSick = rand.nextDouble() < 0.1;
        }
        else {
            age = 0;
            foodLevel = CROCODILE_FOOD_VALUE;
            this.isSick = false;
        }
    }

	@Override
	public void act(List<Animal> newCrocodiles) {
		incrementAge(MAX_AGE);
        incrementHunger();
        if(isAlive()) {
            giveBirth(newCrocodiles);            
            // Move towards a source of food if found.
            Location newLocation = findFood();
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
		
	}

}